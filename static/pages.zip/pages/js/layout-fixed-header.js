(function($) {
    "use strict"

    new dlabSettings({
        headerPosition: "fixed",
    });


})(jQuery);